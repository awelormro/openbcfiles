k = 'Hola mundo!'

print(k)

k=input('modifica tu variable \n')

print(k)
