k=100
while k>0:
    print(k)
    k-=1
