def suma(a,b):
    """docstring for suma"""
    return a+b

def resta(a,b):
    """docstring for resta"""
    return a-b
def mult(a,b):
    """docstring for mult"""
    return a*b
    
def div(a,b):
    """docstring for mult"""
    return a/b
