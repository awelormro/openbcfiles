from operaciones.operaciones import *

print(suma(3,5))
print(resta(3,5))
print(mult(3,5))
print(div(3,5))
