k='Hola mundo!'

print(k)
